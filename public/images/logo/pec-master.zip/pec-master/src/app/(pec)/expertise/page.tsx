import Expertise from "@/features/expertise/expertise";

export default function Page() {
  return <Expertise />;
}
