import Industries from "@/features/industries/industries";

export default function Page() {
  return <Industries />;
}
