import Materials from "@/features/industries/materials/materials";
import Water from "@/features/industries/water/water";

export default function Page() {
  return <Materials />;
}
