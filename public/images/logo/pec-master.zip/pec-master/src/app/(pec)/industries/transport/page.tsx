import Transport from "@/features/industries/transport/transport";

export default function Page() {
  return <Transport />;
}
