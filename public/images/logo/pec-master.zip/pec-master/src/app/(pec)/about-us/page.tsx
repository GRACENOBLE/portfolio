import AboutUs from "@/features/about-us/about-us";

export default function Page() {
  return <AboutUs />;
}
