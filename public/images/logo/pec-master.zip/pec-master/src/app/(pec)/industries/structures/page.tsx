import Structures from "@/features/industries/structures/structures";

export default function Page() {
  return <Structures />;
}
