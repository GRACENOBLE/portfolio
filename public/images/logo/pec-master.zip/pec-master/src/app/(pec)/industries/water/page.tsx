import Water from "@/features/industries/water/water";

export default function Page() {
  return <Water />;
}
