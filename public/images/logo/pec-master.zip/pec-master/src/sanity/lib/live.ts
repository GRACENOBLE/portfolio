// Querying with "sanityFetch" will keep content automatically updated
// Before using it, import and render "<SanityLive />" in your layout, see
// https://github.com/sanity-io/next-sanity#live-content-api for more information.
import { defineLive } from "next-sanity";
import { client } from "./client";

// set your viewer token
const token = process.env.SANITY_API_READ_TOKEN;

if (!token) {
  throw new Error("MISSING SANITY_API_READ_TOKEN");
}

export const { sanityFetch, SanityLive } = defineLive({
  client: client.withConfig({
    apiVersion: "vX", // Target the experimental API version
  }),
  serverToken: token,
  browserToken: token,
  fetchOptions: {
    revalidate: 0,
  },
});
