import { PDFViewer } from "@react-pdf/renderer";
export default PDFViewer;
